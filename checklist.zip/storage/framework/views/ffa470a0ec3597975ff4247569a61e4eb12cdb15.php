<form id="logout" method="POST" action="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                    <?php echo csrf_field(); ?>
                  
</form>					
<script>

	function signOut() {
		
		 swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, let me signout!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false
            }).then(function (result) {
				if(result.value == true){
				$('#logout').trigger('submit')
				}
            });
	
	}
	
	 
	function goBack() {
		window.history.back();
	}
	$(".loader").hide();
	var image = "<?php echo e(url('assets/images/web/loading.gif')); ?>";
	var $loading = $(".loader").html( '<img class="loading-image" src="'+image+'" alt="loading..">');
		 jQuery(document).ajaxStart(function () {
				   
					$loading.show();
			});
			
		 jQuery(document).ajaxStop(function () {
				$(".card").fadeIn("slow", function() {
				$loading.hide();
				
		});
		 });
		 
	$(window).on('shown.bs.modal', function() { 
    $("body").removeAttr("style");
	});
	
</script>
<?php /**PATH C:\xampp\htdocs\checklist\resources\views/backend/footer.blade.php ENDPATH**/ ?>