<?php

namespace App\Http\Controllers\Dashboard;
use Illuminate\Http\Request;
use App\Http\Controllers\Dashboard as Controller;


class CeklistKendaraan extends Controller
{
    //
	public function index(){
		
		$data['title']   = 'List Ceklist Kendaraan';
		$data['user']    = $this->user();
		return view('backend.content.ceklistKendaraan.list',compact('data'));
	}
	
	public function view($id){
		
		$data['title']   = 'Open Detail Ceklist Kendaraan';
		$data['user']    = $this->user();
		return view('backend.content.ceklistKendaraan.view',compact('data'));
	}
	
	public function create(){
		
		
		$data['title']   = 'Add Ceklist Kendaraan';
		$data['user']    = $this->user();
		return view('backend.content.ceklistKendaraan.add',compact('data'));	
	}
	
	public function update($id){
		
		$data['title']   = 'Update Ceklist Kendaraan';
		$data['user']    = $this->user();
		return view('backend.content.ceklistKendaraan.add',compact('data'));
	}
	
	
}
